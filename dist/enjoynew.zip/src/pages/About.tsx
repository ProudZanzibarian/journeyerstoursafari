import AboutSection from "../components/AboutSection";




function About() {
  
  return (
    <>
      <AboutSection/>
    </>
  );
}

export default About;
