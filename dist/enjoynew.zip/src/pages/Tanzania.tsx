import { useState, useEffect } from "react";
import GallerySection from "../components/GallerySection";
import UpperSection from "../components/UpperSection";

function Tanzania() {
  const [galleryItems, setGalleryItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetch("./src/assets/data.json")
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        setGalleryItems(data.TanGallery);
        setLoading(false);
      })
      .catch((error) => {
        setError(error.message);
        setLoading(false);
      });
  }, []);

  return (
    <>
      <UpperSection name=" Tanzania " />
      {loading ? (
        <p>Loading...</p>
      ) : error ? (
        <p>Error: {error}</p>
      ) : (
        <GallerySection galleryItems={galleryItems} />
      )}
    </>
  );
}

export default Tanzania;
